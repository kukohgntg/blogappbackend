<?php

namespace Illuminate\Contracts\Queue;

interface ShouldBeUniqueUntilProcessing extends ShouldBeUnique
{
    //
}
